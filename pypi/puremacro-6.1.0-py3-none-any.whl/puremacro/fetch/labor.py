"""OECD LFS sex × age × measure panel fetcher (SDMX-CSV).

The OECD's Labour Force Statistics ``DSD_LFS`` dataflows return
sex × age × measure × country × time observations in SDMX-CSV. This
module builds the dot-key, fetches via :func:`puremacro.fetch.sdmx.sdmx_get`,
and reshapes the response into a long-format panel keyed on
``(code, date, sex, age)`` with measures pivoted to columns and
the three standard rates pre-computed.

Public API
----------
- :func:`fetch_oecd_lfs_panel` — main entry point.

A local CSV/Excel fallback is supported via ``csv_path=`` so the
fetcher works offline against pre-downloaded SDMX dumps or a curated
``LABOR.xlsx`` (with the ``path::sheet`` syntax).

References
----------
SDMX-CSV format: https://sdmx.org/?page_id=4345
OECD SDMX:       https://sdmx.oecd.org/public/rest/
DSD_LFS dataflows: see https://sdmx.oecd.org/public/rest/dataflow/OECD.SDD.TPS/all/latest
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .sdmx import sdmx_get


# Dot-key skeletons per dataflow: the dimensions of ``DSD_LFS`` in the order
# the SDMX key lists them. Every flow below shares that DSD, and its order is
#
#   REF_AREA.MEASURE.UNIT_MEASURE.TRANSFORMATION.ADJUSTMENT.SEX.AGE.ACTIVITY.FREQ
#
# with FREQ *last*. Until 4.7 the templates put FREQ first (the pre-2024
# OECD.Stat layout), which the OECD answers with HTTP 404 "NoResultsFound"
# for every key, so every live call of :func:`fetch_oecd_lfs_panel` failed.
_LFS_DIMS: tuple[str, ...] = (
    "area", "measure", "unit", "transform", "adjust",
    "sex", "age", "activity", "freq",
)
_DATAFLOW_KEY_TEMPLATES: dict[str, tuple[str, ...]] = {
    "DSD_LFS@DF_IALFS_INDIC": _LFS_DIMS,
    "DSD_LFS@DF_IALFS_EMP_Q": _LFS_DIMS,
    "DSD_LFS@DF_IALFS_UNE_Q": _LFS_DIMS,
    "DSD_LFS@DF_IALFS_EMP_BY_AR": _LFS_DIMS,
}

#: Measure codes of the pre-2024 layout that the current flows publish under
#: another name. ``IPOP`` (inactive population) is ``OLF`` ("outside the labour
#: force") today; a key naming ``IPOP`` matches nothing.
_LEGACY_MEASURES: dict[str, str] = {"IPOP": "OLF"}


def _build_lfs_key(
    *,
    dataflow: str,
    countries: list[str] | None,
    sexes: tuple[str, ...],
    ages: tuple[str, ...],
    measures: tuple[str, ...],
    activities: tuple[str, ...] | None,
    frequency: str,
    adjustment: str,
    unit: str | None = "PS",
) -> str:
    """Assemble the SDMX dot-key for an OECD LFS dataflow.

    Lists collapse to ``+``-joined strings; ``None`` becomes empty (which
    SDMX interprets as "all values for that dimension"). ``unit`` pins
    UNIT_MEASURE, ``"PS"`` (persons) by default: left open, the level
    measures also come back as growth rates (``GR``), and the pivot in
    :func:`_reshape_lfs_csv` would keep whichever row it met first. Legacy
    measure codes are translated (``IPOP`` -> ``OLF``).
    """
    if dataflow not in _DATAFLOW_KEY_TEMPLATES:
        raise ValueError(
            f"dataflow {dataflow!r} not in known LFS templates: "
            f"{sorted(_DATAFLOW_KEY_TEMPLATES)}"
        )
    template = _DATAFLOW_KEY_TEMPLATES[dataflow]

    def _join(xs):
        if xs is None:
            return ""
        return "+".join(xs)

    slots = {
        "freq":      frequency,
        "area":      _join(countries),
        "measure":   _join(None if measures is None else
                           [_LEGACY_MEASURES.get(m, m) for m in measures]),
        "unit":      unit or "",
        "transform": "",
        "adjust":    adjustment,
        "sex":       _join(sexes),
        "age":       _join(ages),
        "activity":  _join(activities),
    }
    return ".".join(slots[name] for name in template)


# Map raw OECD MEASURE codes → lowercased canonical column names.
_MEASURE_RENAME: dict[str, str] = {
    "WAP":  "wa",
    "LF":   "lf",
    "EMP":  "emp",
    "UNE":  "une",
    "OLF":  "ina",
    "IPOP": "ina",      # pre-2024 code, still found in local LABOR.xlsx dumps
}


def _parse_time_period(s: pd.Series) -> pd.Series:
    """Parse OECD TIME_PERIOD strings ('2020-01', '2020-Q1', '2020') to first-of-period datetimes."""
    s = s.astype(str)
    is_q = s.str.contains("Q")
    out = pd.Series(pd.NaT, index=s.index, dtype="datetime64[ns]")
    out.loc[~is_q] = pd.to_datetime(s[~is_q], errors="coerce")
    out.loc[is_q] = pd.PeriodIndex(s[is_q], freq="Q").to_timestamp()
    return out


# Synthesis rules: target_age <- signed sum of source_age levels.
# Order matters: later rules may reference earlier synthesized targets
# (e.g. Y55T64 uses Y25T54).
_AGE_SYNTHESIS_RULES: list[tuple[str, list[tuple[str, str]]]] = [
    ("Y25T54", [("+", "25-34"), ("+", "35-44"), ("+", "45-54")]),
    ("Y15T24", [("+", "15-64"), ("-", "25+"),   ("+", "65+")]),
    # Fallback for países that report only 15+, 25+ (most of Europe in LABOR.xlsx).
    # Y15T24 = Y_GE15 - 25+ is exact since 15+ = (15-24) + 25+.
    # Note: _xlsx_to_sdmx_long maps "15+" → "Y_GE15", so the source is Y_GE15 here.
    ("Y15T24", [("+", "Y_GE15"), ("-", "25+")]),
    ("Y55T64", [("+", "25+"),   ("-", "Y25T54"), ("-", "65+")]),
]

_LEVEL_COLS: tuple[str, ...] = ("wa", "lf", "emp", "une", "ina")


def _synthesize_age_aggregates(wide: pd.DataFrame) -> pd.DataFrame:
    """Add synthetic SDMX age cells derived from EU-style 5-year bands.

    Each rule in :data:`_AGE_SYNTHESIS_RULES` fires per ``(code, date, sex)``
    cell when (a) the target age is absent and (b) every source age is
    present with non-NaN level data. Levels are summed with the signs
    given by the rule; rates are not derived here (that happens later
    in :func:`_reshape_lfs_csv`).

    Rules are applied sequentially, so later rules can reference age
    cells synthesized by earlier rules (e.g. ``Y55T64`` is computed
    from a ``Y25T54`` that may itself have just been synthesized).
    """
    if wide.empty:
        return wide

    out = wide.copy()
    key = ["code", "date", "sex"]
    for target_age, parts in _AGE_SYNTHESIS_RULES:
        signs = {age: (1 if sign == "+" else -1) for sign, age in parts}
        source_ages = list(signs)

        relevant = out[out["age"].isin([target_age, *source_ages])]
        if relevant.empty:
            continue
        # If any source age is absent from the frame entirely, no cell can
        # satisfy the rule. This is the common case and it used to be the
        # expensive one: with the default `ages=("Y_GE15","Y15T24","Y25T54",
        # "Y55T64")` none of the 5-year source bands exist, so every cell fell
        # through -- after a per-cell `.xs` on a 4-level MultiIndex. That was
        # 101 s spent returning the input unchanged on a 172,800-row frame.
        present_ages = set(relevant["age"].unique())
        if not set(source_ages) <= present_ages:
            continue

        # One pivot instead of a lookup per (cell, age). `unstack` keeps NaN
        # level values as NaN, which the eligibility test below needs to see;
        # `pivot_table` would drop them.
        idx = relevant.set_index(key + ["age"])
        if idx.index.has_duplicates:
            raise ValueError(
                "_synthesize_age_aggregates: duplicate (code, date, sex, age) "
                "rows; the level pivot is not well defined for them."
            )
        vals = idx[list(_LEVEL_COLS)].unstack("age")
        pres = idx.assign(_p=1).groupby(key + ["age"])["_p"].first().unstack("age")

        # (a) the target age is absent, (b) every source age is present, and
        # (c) every level column is non-NaN for every source age -- the last
        # one matched the old `ok` flag, which abandoned the whole row on the
        # first NaN in any column.
        eligible = (pres[target_age].isna() if target_age in pres.columns
                    else pd.Series(True, index=pres.index))
        eligible &= pres[source_ages].notna().all(axis=1)
        for col in _LEVEL_COLS:
            eligible &= vals[[(col, a) for a in source_ages]].notna().all(axis=1)
        if not eligible.any():
            continue

        # Preserve the row order the per-cell loop produced: first appearance
        # in `out`, not the pivot's sorted order.
        order = relevant[key].drop_duplicates()
        order = order[pd.MultiIndex.from_frame(order).isin(
            eligible.index[eligible.to_numpy()])]
        take = pd.MultiIndex.from_frame(order)

        new = pd.DataFrame(index=take)
        for col in _LEVEL_COLS:
            new[col] = sum(signs[a] * vals[(col, a)] for a in source_ages).loc[take]
        new = new.reset_index()
        new["age"] = target_age
        out = pd.concat([out, new[key + ["age"] + list(_LEVEL_COLS)]],
                        ignore_index=True)

    return out


def _reshape_lfs_csv(raw: pd.DataFrame, *, frequency: str) -> pd.DataFrame:
    """Reshape an SDMX-CSV LFS response into a canonical long panel.

    Returns columns ``code, date, sex, age, wa, lf, emp, une, ina,
    urate, epop, prate``. Rows where FREQ != ``frequency`` are dropped.
    """
    df = raw.loc[raw["FREQ"] == frequency, [
        "REF_AREA", "TIME_PERIOD", "SEX", "AGE", "MEASURE", "OBS_VALUE",
    ]].copy()
    df = df.rename(columns={
        "REF_AREA":    "code",
        "TIME_PERIOD": "date",
        "SEX":         "sex",
        "AGE":         "age",
    })
    df["date"] = _parse_time_period(df["date"])
    df["OBS_VALUE"] = pd.to_numeric(df["OBS_VALUE"], errors="coerce")

    wide = (
        df.pivot_table(
            index=["code", "date", "sex", "age"],
            columns="MEASURE",
            values="OBS_VALUE",
            aggfunc="first",
        )
        .rename(columns=_MEASURE_RENAME)
        .reset_index()
    )
    wide.columns.name = None

    # Ensure all canonical level columns exist (missing → NaN).
    for col in ("wa", "lf", "emp", "une", "ina"):
        if col not in wide.columns:
            wide[col] = np.nan

    # Synthesize SDMX age aggregates from 5-year bands where possible.
    wide = _synthesize_age_aggregates(wide)

    # Synthesize ina = wa - lf where IPOP-derived ina is NaN but wa, lf are present.
    needs_synth = wide["ina"].isna() & wide["wa"].notna() & wide["lf"].notna()
    wide.loc[needs_synth, "ina"] = wide.loc[needs_synth, "wa"] - wide.loc[needs_synth, "lf"]

    # Derive rates with explicit positive-denominator masks (no try/except).
    def _rate(num_col: str, den_col: str) -> pd.Series:
        num = wide[num_col]
        den = wide[den_col]
        mask = den.notna() & (den > 0)
        out = pd.Series(np.nan, index=wide.index, dtype="float64")
        out.loc[mask] = num[mask] / den[mask]
        return out

    wide["urate"] = _rate("une", "lf")
    wide["epop"]  = _rate("emp", "wa")
    wide["prate"] = _rate("lf",  "wa")

    keep = ["code", "date", "sex", "age",
            "wa", "lf", "emp", "une", "ina",
            "urate", "epop", "prate"]
    out = wide[keep].sort_values(["code", "date", "sex", "age"]).reset_index(drop=True)
    return out


# Sex label normalization for the LABOR.xlsx adapter.
_XLSX_SEX_MAP: dict[str, str] = {
    "Total": "_T", "T": "_T", "_T": "_T",
    "Male":  "M",  "M": "M",
    "Female": "F", "F": "F",
}

# LABOR.xlsx-style age labels → OECD LFS codes.
_XLSX_AGE_MAP: dict[str, str] = {
    "15+":   "Y_GE15",
    "15-24": "Y15T24",
    "25-54": "Y25T54",
    "55-64": "Y55T64",
    "55+":   "Y_GE55",
}


def _read_local_input(csv_path: str | Path) -> pd.DataFrame:
    """Read a local SDMX-CSV file or a LABOR.xlsx ``path::sheet`` spec.

    For ``.xlsx`` inputs, normalize column names and sex/age labels to
    the SDMX convention so the downstream :func:`_reshape_lfs_csv`
    sees a uniform schema.
    """
    s = str(csv_path)
    if "::" in s:
        path_part, sheet = s.split("::", 1)
        path = Path(path_part)
        if not path.exists():
            raise FileNotFoundError(f"xlsx not found: {path}")
        try:
            raw = pd.read_excel(path, sheet_name=sheet)
        except ValueError as exc:
            # pandas raises ValueError for missing sheet — re-raise as KeyError
            # so callers can distinguish "wrong file" from "wrong sheet".
            raise KeyError(
                f"sheet {sheet!r} not in {path}; "
                f"available: {pd.ExcelFile(path).sheet_names}"
            ) from exc
        return _xlsx_to_sdmx_long(raw)
    return pd.read_csv(s)


def _xlsx_to_sdmx_long(df: pd.DataFrame) -> pd.DataFrame:
    """Convert a LABOR.xlsx OECD-AGE-M sheet to SDMX-CSV-shaped long format."""
    df = df.copy()
    rename = {
        "Code":   "REF_AREA",
        "Period": "TIME_PERIOD",
        "Sex":    "SEX",
        "Age":    "AGE",
    }
    df = df.rename(columns=rename)

    # Normalize sex / age labels.
    df["SEX"] = df["SEX"].map(_XLSX_SEX_MAP).fillna(df["SEX"])
    df["AGE"] = df["AGE"].map(_XLSX_AGE_MAP).fillna(df["AGE"])

    # Identify level columns: anything not in the index set.
    index_cols = ["REF_AREA", "TIME_PERIOD", "SEX", "AGE"]
    level_cols = [c for c in df.columns if c not in index_cols]

    long = df.melt(
        id_vars=index_cols,
        value_vars=level_cols,
        var_name="MEASURE",
        value_name="OBS_VALUE",
    )
    # Map LABOR.xlsx lowercase measure names → SDMX uppercase.
    measure_up = {"emp": "EMP", "lf": "LF", "une": "UNE",
                  "wa": "WAP", "ina": "IPOP", "olf": "IPOP"}
    long["MEASURE"] = long["MEASURE"].map(measure_up).fillna(long["MEASURE"].str.upper())
    long["FREQ"] = "M"
    return long


def fetch_oecd_lfs_panel(
    *,
    dataflow: str = "DSD_LFS@DF_IALFS_INDIC",
    countries: list[str] | None = None,
    sexes:     tuple[str, ...] = ("_T", "M", "F"),
    ages:      tuple[str, ...] = ("Y_GE15", "Y15T24", "Y25T54", "Y55T64"),
    measures:  tuple[str, ...] = ("WAP", "LF", "EMP", "UNE", "OLF"),
    activities: tuple[str, ...] | None = None,
    frequency: str = "M",
    adjustment: str = "Y",
    csv_path:  str | Path | None = None,
    cache_path: str | Path | None = None,
    refresh:   bool = False,
) -> pd.DataFrame:
    """Fetch an OECD LFS sex × age × measure panel as a long DataFrame.

    Parameters
    ----------
    dataflow : str
        OECD SDMX dataflow ID. Default ``"DSD_LFS@DF_IALFS_INDIC"`` returns
        infra-annual labour-stats indicators (WAP, LF, EMP, UNE, OLF; the
        legacy code ``IPOP`` is accepted and sent as ``OLF``).
        Use ``"DSD_LFS@DF_IALFS_EMP_BY_AR"`` for sex × ISIC sector
        employment.
    countries : list[str] | None
        ISO-3 country codes; ``None`` returns all reporters.
    sexes, ages, measures, activities : tuple[str, ...] | None
        OECD enum codes. ``None`` selects all.
    frequency : str
        ``"M"`` or ``"Q"`` (or ``"A"`` for annual). Mixed-frequency rows
        in the SDMX response are filtered to this value.
    adjustment : str
        ``"Y"`` (calendar + seasonally adjusted, default) or ``"N"`` (NSA).
    csv_path : str | Path | None
        Local SDMX-CSV file or LABOR.xlsx ``"path::sheet"`` spec. When
        set and the file exists, network fetch is skipped.
    cache_path : str | Path | None
        Parquet cache. If exists and ``refresh=False``, returned without
        any reshape work.
    refresh : bool
        Force re-fetch (ignore cache).

    Returns
    -------
    pd.DataFrame
        Long panel with columns ``code, date, sex, age, wa, lf, emp,
        une, ina, urate, epop, prate``. Sorted by
        ``(code, date, sex, age)``.
    """
    # 1. Cache fast path.
    if cache_path is not None and not refresh:
        cp = Path(cache_path)
        if cp.exists():
            return pd.read_parquet(cp)

    # 2. Local file fast path.
    if csv_path is not None:
        raw = _read_local_input(csv_path)
    else:
        # 3. Live SDMX.
        key = _build_lfs_key(
            dataflow=dataflow, countries=countries, sexes=sexes, ages=ages,
            measures=measures, activities=activities,
            frequency=frequency, adjustment=adjustment,
        )
        raw = sdmx_get(provider="oecd", dataflow=dataflow, key=key)

    out = _reshape_lfs_csv(raw, frequency=frequency)

    # 4. Cache write.
    if cache_path is not None:
        cp = Path(cache_path)
        cp.parent.mkdir(parents=True, exist_ok=True)
        out.to_parquet(cp, index=False)

    return out


def fetch_sectoral_panel_union(panels: list[pd.DataFrame]) -> pd.DataFrame:
    """Combine canonical-schema sectoral panels with priority-first column merge.

    For each ``(code, date, sex, eco, column)`` cell, the first listed
    panel's value wins **if non-NaN**; otherwise the next panel fills in.
    Mirrors :func:`fetch_labor_panel_union` for the sectoral 6-col schema:
    ``[code, date, sex, eco, emp, hours_worked]``.

    Parameters
    ----------
    panels : list[pd.DataFrame]
        Frames to combine. Earlier frames win on duplicate keys
        — column-wise, NaN-aware.

    Returns
    -------
    pd.DataFrame
        Combined, sorted on ``(code, date, sex, eco)`` with reset index.
    """
    canonical = ["code", "date", "sex", "eco", "emp", "hours_worked"]
    index_cols = ["code", "date", "sex", "eco"]
    if not panels:
        return pd.DataFrame(columns=canonical)
    result = panels[0][canonical].set_index(index_cols)
    for p in panels[1:]:
        result = result.combine_first(p[canonical].set_index(index_cols))
    return (result.reset_index()[canonical]
            .sort_values(index_cols)
            .reset_index(drop=True))


def fetch_labor_panel_union(panels: list[pd.DataFrame]) -> pd.DataFrame:
    """Combine canonical-schema labor panels with priority-first column merge.

    For each ``(code, date, sex, age, column)`` cell, the first listed
    panel's value wins **if non-NaN**; otherwise the next panel fills in.
    This preserves data from a supplementary source (e.g. Eurostat
    ``urate``) on cells where the higher-priority source (e.g. LABOR.xlsx)
    has a NaN.

    The canonical schema is what :func:`fetch_oecd_lfs_panel` and
    :func:`puremacro.fetch.labor_eurostat.fetch_eurostat_lfs_panel`
    return: ``[code, date, sex, age, wa, lf, emp, une, ina, urate,
    epop, prate]``.

    Parameters
    ----------
    panels : list[pd.DataFrame]
        Frames to combine. Earlier frames win on duplicate keys
        — column-wise, NaN-aware.

    Returns
    -------
    pd.DataFrame
        Combined, sorted on ``(code, date, sex, age)`` with reset index.
    """
    canonical = ["code", "date", "sex", "age",
                 "wa", "lf", "emp", "une", "ina",
                 "urate", "epop", "prate"]
    index_cols = ["code", "date", "sex", "age"]
    if not panels:
        return pd.DataFrame(columns=canonical)
    # Set common (code, date, sex, age) index on each panel, keeping only
    # canonical columns. combine_first does NaN-aware fill: result keeps
    # `self`'s non-NaN values; where `self` is NaN, takes the value from
    # `other`. Iterating over panels[1:] applies them in priority order.
    result = panels[0][canonical].set_index(index_cols)
    for p in panels[1:]:
        result = result.combine_first(p[canonical].set_index(index_cols))
    return (result.reset_index()[canonical]
            .sort_values(index_cols)
            .reset_index(drop=True))
