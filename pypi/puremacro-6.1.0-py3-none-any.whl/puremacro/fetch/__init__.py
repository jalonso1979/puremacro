"""puremacro.fetch — public-data fetchers.

Exposes fetchers for major macro/financial data sources, all going
through the unified :mod:`puremacro._http` helpers (UA override,
one-shot SSL fallback, 30s default timeout). Each fetcher returns a
``pandas`` object suitable for direct use in VAR / LP estimation.

Public API
----------
- :func:`fetch_fred`        — FRED public CSV (no API key needed)
- :func:`fetch_fred_alfred` — ALFRED real-time vintages (one series)
- :func:`alfred_vintages`   — every archived edition of one ALFRED series
- :func:`vintage_panel`     — one-call cross-country panel of published
                              editions, across six real-time providers
- :func:`vintage_catalog`   — which series backs which (country, variable)
- :func:`qna_long_panel`    — the OECD spine extended backwards per country by
                              ratio-splicing archived national vintages onto it
                              (Spain to 1970, Japan to 1955)
- :func:`qna_panel`         — one-call cross-country quarterly national accounts
                              (nominal SA levels + implicit deflators, OECD QNA)
- :func:`qna_labor`         — the QNA labour block alone (employment, hours)
- :func:`qna_countries`     — every reference area that flow actually covers
- :func:`qna_rebase`        — put every country on one price reference year
- :func:`qna_identity`      — score all three GDP identities the panel carries
- :func:`qna_contributions` — component contributions to real GDP growth
- :func:`fetch_xrate_monthly` — OECD nominal exchange rates (LCU per USD), monthly
- :func:`sdmx_get`          — generic SDMX-CSV (OECD, Eurostat, ECB, IMF SDMX Central)
- :func:`oecd_sdmx_instrument` — convenience wrapper that returns
                                 :class:`puremacro.instruments.Instrument` directly
- :func:`fetch_wdi_emissions` — World Bank WDI greenhouse gas emissions indicators
- :func:`fetch_oecd_ghg`     — OECD SDMX Air Emissions Inventory sectoral breakdowns
- :func:`fetch_emissions_panel` — unified cross-country emissions panel
- :func:`fetch_energy_transition` — primary energy consumption and electricity by source
- :func:`fetch_commodity_benchmarks` — standardized global commodity benchmark prices and indices
- :func:`fetch_sovereign_yields` — sovereign bond yields (10Y, 2Y)
- :func:`fetch_policy_rates` — central bank policy rates
- :func:`fetch_bis_macroprudential` — BIS credit-to-GDP gap, total credit, and property prices
- :func:`fetch_financial_conditions` — financial conditions indicators and credit risk spreads
- :func:`compute_sovereign_spreads` — sovereign risk and term spreads
- :func:`wdi_panel` — World Bank WDI annual panel, 217 economies from 1960
- :func:`ana_panel` — OECD annual national accounts, the annual twin of qna_panel
- :func:`qna_sector_gfcf` — OECD quarterly GFCF by sector, population, LFS and vacancies
- :func:`stes_panel` — OECD monthly panel: production, prices, rates, labour, confidence
- :func:`eurostat_get` — Eurostat annual/quarterly accounts and monthly indicators
- :func:`imf_get` — IMF data portal (api.imf.org): accounts, CPI, rates, EER, PCPS, WEO, ICSD
- :func:`bis_get` — BIS: effective exchange rates, policy rates, credit, property prices
- :func:`rates_panel` — monthly money-market rates, 10-year yields, stocks, commodities
- :func:`ilostat_panel` — ILOSTAT labour panel (annual, quarterly, monthly; modelled estimates)
- :func:`fetch_pwt` — Penn World Table 11.0 and Maddison Project Database 2023

Discovery and microdata
-----------------------
- :mod:`puremacro.fetch.registry` — every source with its auth, terms and
  loader: ``registry.sources("micro")``, ``registry.load("fed.scf")``
- :mod:`puremacro.fetch.micro`    — survey microdata (ACS PUMS, CPS, SCF)
  returned with weights and a replicate-variance design

For API-key-requiring FRED via the JSON endpoint, see
:func:`puremacro.instruments.external.load_fred`.
"""
from ._classic import (
    _safe_urlopen,
    fetch_fred,
    fetch_fred_alfred,
)
from .sdmx import (
    sdmx_get,
    oecd_sdmx_instrument,
)
from .labor import (
    fetch_oecd_lfs_panel,
    fetch_labor_panel_union,
    fetch_sectoral_panel_union,
)
from .labor_eurostat import fetch_eurostat_lfs_panel
from .labor_ilostat import (
    fetch_ilostat_lfs_panel,
    fetch_ilostat_sectoral_panel,
)
from .jolts import fetch_jolts
from .vacancies_eurostat import fetch_eurostat_vacancies
from .oecd_qna_panel import (
    qna_panel,
    qna_labor,
    qna_meta,
    qna_countries,
    QNA_AGGREGATES,
    QNA_ACTIVITIES,
    QNA_INCOME,
    QNA_VA_ADDITIVE,
    QNA_VA_MEMO,
    QNA_COMPONENTS,
    QNA_ASSETS,
    QNA_DURABILITY,
    QNA_LABOR,
    QNA_LABOR_UNITS,
    QNA_LABOR_ACTIVITIES,
)
from .oecd_ana_activity import (
    ana_by_activity,
    ana_meta,
    ana_hours_wedge,
    chain_volume,
    ANA_ACTIVITIES,
    ANA_LABOR,
    ANA_LABOR_UNITS,
)
from .oecd_fx import fetch_xrate_monthly
from .oecd_qna_tools import (
    qna_rebase,
    qna_identity,
    qna_contributions,
    IDENTITY_TERMS,
    OUTPUT_TERMS,
    INCOME_TERMS,
    APPROACH_GDP,
)
from .qna_vintages import (
    fetch_qna_vintages,
    QNAVintagePanel,
    get_qna_vintage_catalog,
)
from .longpanel import (
    qna_long_panel,
    long_panel_residual,
    LONG_PANEL_SOURCES,
    KNOWN_GAPS as LONG_PANEL_KNOWN_GAPS,
)
from .realtime import (
    alfred_vintages,
    available_providers,
    vintage_catalog,
    vintage_panel,
    seasonal_signature,
    drop_unadjusted_editions,
    VintagePanel,
    VINTAGE_SEMANTICS,
)
from .emissions import (
    fetch_wdi_emissions,
    fetch_oecd_ghg,
    fetch_emissions_panel,
)
from .energy_transition import (
    fetch_energy_transition,
)
from .commodities import (
    fetch_commodity_benchmarks,
)
from .financial import (
    fetch_sovereign_yields,
    fetch_policy_rates,
    fetch_bis_macroprudential,
    fetch_financial_conditions,
    compute_sovereign_spreads,
)

# Cross-country panel builders (4.7): one call per provider, urllib only.
from .wdi import (
    wdi_panel,
    wdi_countries,
    wdi_meta,
    WDI_INDICATORS,
)
from .oecd_ana_panel import (
    ana_panel,
    ana_countries,
    ana_panel_meta,
)
from .oecd_qna_extras import (
    qna_sector_gfcf,
    qna_population,
    oecd_lfs_panel,
    oecd_vacancies,
    qna_extras_meta,
)
from .oecd_stes_panel import (
    stes_panel,
    stes_meta,
    STES_CONCEPTS,
)
from .eurostat import (
    eurostat_get,
    eurostat_codes,
    eurostat_na_panel,
    eurostat_monthly_panel,
    eurostat_meta,
)
from .imf import (
    imf_get,
    imf_dataflows,
    imf_nea_panel,
    imf_monthly_panel,
    imf_labour_panel,
    imf_pcps,
    imf_weo,
    imf_icsd,
    imf_meta,
)
from .bis import (
    bis_get,
    bis_countries,
    bis_panel,
    bis_eer,
    bis_meta,
    BIS_SERIES,
)
from .rates import (
    rates_panel,
    stock_index_monthly,
    commodity_prices_monthly,
    fetch_fred_many,
    ecb_get,
)
from .ilostat import (
    ilostat_panel,
    ilostat_meta,
    ILOSTAT_VARS,
)
from .pwt import (
    fetch_pwt,
    fetch_maddison,
    pwt_variables,
)

__all__ = [
    "fetch_fred",
    "fetch_fred_alfred",
    "alfred_vintages",
    "vintage_panel",
    "seasonal_signature",
    "drop_unadjusted_editions",
    "qna_long_panel",
    "long_panel_residual",
    "LONG_PANEL_SOURCES",
    "LONG_PANEL_KNOWN_GAPS",
    "VintagePanel",
    "vintage_catalog",
    "available_providers",
    "VINTAGE_SEMANTICS",
    "qna_panel",
    "qna_labor",
    "qna_meta",
    "ana_by_activity",
    "ana_meta",
    "ana_hours_wedge",
    "chain_volume",
    "ANA_ACTIVITIES",
    "ANA_LABOR",
    "ANA_LABOR_UNITS",
    "QNA_LABOR_ACTIVITIES",
    "qna_countries",
    "QNA_AGGREGATES",
    "qna_rebase",
    "qna_identity",
    "qna_contributions",
    "IDENTITY_TERMS",
    "OUTPUT_TERMS",
    "INCOME_TERMS",
    "APPROACH_GDP",
    "QNA_ACTIVITIES",
    "QNA_INCOME",
    "QNA_VA_ADDITIVE",
    "QNA_VA_MEMO",
    "QNA_COMPONENTS",
    "QNA_ASSETS",
    "QNA_DURABILITY",
    "QNA_LABOR",
    "QNA_LABOR_UNITS",
    "fetch_xrate_monthly",
    "fetch_qna_vintages",
    "QNAVintagePanel",
    "get_qna_vintage_catalog",
    "sdmx_get",
    "oecd_sdmx_instrument",
    "fetch_oecd_lfs_panel",
    "fetch_eurostat_lfs_panel",
    "fetch_labor_panel_union",
    "fetch_ilostat_lfs_panel",
    "fetch_ilostat_sectoral_panel",
    "fetch_sectoral_panel_union",
    "fetch_jolts",
    "fetch_eurostat_vacancies",
    "fetch_wdi_emissions",
    "fetch_oecd_ghg",
    "fetch_emissions_panel",
    "fetch_energy_transition",
    "fetch_commodity_benchmarks",
    "fetch_sovereign_yields",
    "fetch_policy_rates",
    "fetch_bis_macroprudential",
    "fetch_financial_conditions",
    "compute_sovereign_spreads",
    "wdi_panel",
    "wdi_countries",
    "wdi_meta",
    "WDI_INDICATORS",
    "ana_panel",
    "ana_countries",
    "ana_panel_meta",
    "qna_sector_gfcf",
    "qna_population",
    "oecd_lfs_panel",
    "oecd_vacancies",
    "qna_extras_meta",
    "stes_panel",
    "stes_meta",
    "STES_CONCEPTS",
    "eurostat_get",
    "eurostat_codes",
    "eurostat_na_panel",
    "eurostat_monthly_panel",
    "eurostat_meta",
    "imf_get",
    "imf_dataflows",
    "imf_nea_panel",
    "imf_monthly_panel",
    "imf_labour_panel",
    "imf_pcps",
    "imf_weo",
    "imf_icsd",
    "imf_meta",
    "bis_get",
    "bis_countries",
    "bis_panel",
    "bis_eer",
    "bis_meta",
    "BIS_SERIES",
    "rates_panel",
    "stock_index_monthly",
    "commodity_prices_monthly",
    "fetch_fred_many",
    "ecb_get",
    "ilostat_panel",
    "ilostat_meta",
    "ILOSTAT_VARS",
    "fetch_pwt",
    "fetch_maddison",
    "pwt_variables",
]
