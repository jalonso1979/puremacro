"""puremacro-dynare — Drop-in command-line runner for Dynare .mod models.

Executes Dynare .mod macroeconomic models in pure Python with zero C++ compilation.
Computes steady states, 1st and 2nd order decision rules, IRFs, FEVD, historical
shock decompositions, and exports publication-ready LaTeX, Typst, and Markdown tables.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd


class DynareParser(argparse.ArgumentParser):
    """Dual-mode parser supporting both legacy model solving and parity verification."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._parity_parser = argparse.ArgumentParser(
            prog="puremacro-dynare parity",
            description="Run automated parity verification against Dynare golden outputs.",
        )
        self._parity_parser.add_argument(
            "path",
            nargs="?",
            default=".",
            help="Path to a .mod file or a directory of models. Default: .",
        )
        self._parity_parser.add_argument(
            "--order",
            type=int,
            choices=[1, 2],
            default=1,
            help="Perturbation order to verify (1 or 2). Default: 1.",
        )
        self._parity_parser.add_argument(
            "--tol",
            type=float,
            default=None,
            help="Maximum absolute deviation tolerance override.",
        )
        self._parity_parser.add_argument(
            "--format",
            choices=["markdown", "latex", "typst", "all", "text"],
            default="text",
            help="Output scorecard format. Default: text.",
        )
        self._parity_parser.add_argument(
            "--outdir",
            type=str,
            default=None,
            help="Directory to export scorecard artifacts.",
        )
        self._parity_parser.add_argument(
            "--quiet",
            action="store_true",
            help="Suppress terminal summary output.",
        )
        self._parity_parser.set_defaults(command="parity")
        self._inspect_parser = argparse.ArgumentParser(
            prog="puremacro-dynare inspect", description="Inspect .mod compatibility without solving.")
        self._inspect_parser.add_argument("model")
        self._inspect_parser.add_argument("--entry-point", choices=["load_mod", "execute_mod_commands", "load_hank_mod"], default="execute_mod_commands")
        self._inspect_parser.add_argument("--ordered", action="store_true")
        self._inspect_parser.add_argument("--format", choices=["text", "json"], default="text")
        self._inspect_parser.add_argument("--output", help="Explicit path to write the report; default stdout only")
        self._inspect_parser.add_argument("--macro-limit", type=int, default=100000)
        self._inspect_parser.set_defaults(command="inspect")
        self._execute_parser = argparse.ArgumentParser(
            prog="puremacro-dynare execute",
            description="Inspect and execute a source-ordered .mod command program without a QZ prerequisite.",
        )
        self._execute_parser.add_argument("model", help="Path to the Dynare .mod file.")
        self._execute_parser.add_argument(
            "--outdir",
            type=str,
            default="./dynare_results",
            help="Directory to save deterministic command outputs. Default: ./dynare_results.",
        )
        self._execute_parser.add_argument(
            "--format",
            choices=["markdown", "latex", "typst", "all", "json"],
            default="all",
            help="Export format for summary tables. Default: all.",
        )
        self._execute_parser.add_argument(
            "--data",
            type=str,
            default=None,
            metavar="DATA_CSV",
            help="Optional CSV dataset for calib_smoother or shock_decomposition commands.",
        )
        self._execute_parser.add_argument(
            "--macro-limit",
            type=int,
            default=100000,
            help="Maximum macro expansion budget. Default: 100000.",
        )
        self._execute_parser.add_argument(
            "--plot",
            action="store_true",
            help="Save trajectory or IRF figures (PNG) in outdir.",
        )
        self._execute_parser.add_argument(
            "--quiet",
            action="store_true",
            help="Suppress terminal output.",
        )
        self._execute_parser.set_defaults(command="execute", ordered=True)

    def parse_args(self, args=None, namespace=None):
        if args is None:
            args = sys.argv[1:]
        if args and args[0] == "inspect":
            return self._inspect_parser.parse_args(args[1:], namespace=namespace)
        if args and args[0] == "execute":
            return self._execute_parser.parse_args(args[1:], namespace=namespace)
        if args and args[0] == "parity":
            return self._parity_parser.parse_args(args[1:], namespace=namespace)
        ns = super().parse_args(args, namespace=namespace)
        if not hasattr(ns, "command"):
            ns.command = "execute" if getattr(ns, "ordered", False) else "solve"
        return ns


def create_parser() -> argparse.ArgumentParser:
    parser = DynareParser(
        prog="puremacro-dynare",
        description="Run Dynare .mod macroeconomic models in pure Python without MATLAB/C++.",
    )
    parser.add_argument(
        "model",
        type=str,
        help="Path to the Dynare .mod file (e.g. model.mod or sw07.mod).",
    )
    parser.add_argument(
        "--order",
        type=int,
        choices=[1, 2],
        default=1,
        help="Perturbation order: 1 (linear Klein QZ) or 2 (pruned 2nd order). Default: 1.",
    )
    parser.add_argument(
        "--irf",
        type=int,
        default=40,
        help="Impulse response horizon in periods. Default: 40.",
    )
    parser.add_argument(
        "--fevd",
        action="store_true",
        help="Compute and export Forecast Error Variance Decomposition (FEVD).",
    )
    parser.add_argument(
        "--shock-decomp",
        type=str,
        default=None,
        metavar="DATA_CSV",
        help="Compute historical shock decomposition using observed series in DATA_CSV.",
    )
    parser.add_argument(
        "--periods",
        type=int,
        default=0,
        help="Stochastic simulation length in periods (0 to skip stochastic simulation). Default: 0.",
    )
    parser.add_argument(
        "--outdir",
        type=str,
        default="./dynare_results",
        help="Directory to save generated tables and figures. Default: ./dynare_results.",
    )
    parser.add_argument(
        "--format",
        choices=["markdown", "latex", "typst", "all"],
        default="all",
        help="Publication export format for tables. Default: all.",
    )
    parser.add_argument(
        "--plot",
        action="store_true",
        help="Save IRF and FEVD figures (PNG) in outdir.",
    )
    parser.add_argument(
        "--steady-only",
        action="store_true",
        help="Compute and display steady state without solving dynamic perturbation.",
    )
    parser.add_argument(
        "--ordered",
        action="store_true",
        help="Execute the .mod file as a validated source-ordered command program via read_mod.",
    )
    parser.add_argument(
        "--data",
        type=str,
        default=None,
        metavar="DATA_CSV",
        help="Optional CSV dataset for ordered calib_smoother or shock_decomposition commands.",
    )
    parser.add_argument(
        "--macro-limit",
        type=int,
        default=100000,
        help="Maximum macro expansion budget when inspecting ordered programs.",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress interactive terminal output.",
    )
    return parser


def run_parity_cli(args: argparse.Namespace) -> int:
    """Execute parity verification subcommand."""
    target_path = Path(args.path)
    if not target_path.exists():
        sys.stderr.write(f"Error: Path '{target_path}' not found.\n")
        return 1

    if target_path.is_file() and target_path.suffix == ".mat":
        sys.stderr.write(
            "Error: puremacro 4.0.0 no longer reads MATLAB .mat files. Load the "
            "Dynare oo_ structure yourself and call "
            "puremacro.dsge.verify_dynare_parity(model, oo_dict).\n"
        )
        return 1
    if target_path.is_file() and target_path.suffix != ".mod":
        sys.stderr.write(
            f"Error: Unrecognized file type '{target_path.suffix}'; expected .mod\n"
        )
        return 1

    # Comparing against Dynare needs its oo_ output, which only the caller can
    # load now that puremacro reads no MATLAB files. Rather than run a suite
    # that can verify nothing and report success, say so and fail.
    sys.stderr.write(
        "Error: `puremacro-dynare parity` cannot compare against Dynare from the "
        "command line since 4.0.0, because puremacro no longer reads "
        "*_results.mat. Load each reference yourself and call:\n"
        "    from puremacro.dsge import run_parity_suite\n"
        "    run_parity_suite(directory, dynare_results={'model_stem': oo_dict})\n"
    )
    return 1


def _bk_status_line(model) -> str:
    """Blanchard-Kahn verdict read off the solved model, never assumed."""
    first = getattr(model, "first_order", None)
    src = first if first is not None else model
    solution = getattr(src, "solution", None)
    eu = tuple(getattr(solution, "eu", ())) if solution is not None else ()
    if eu == (1, 1):
        return "Blanchard-Kahn condition verified: unique stable rational expectations path."
    if eu == (1, 0):
        return "Blanchard-Kahn condition FAILED: indeterminacy (multiple stable solutions)."
    if eu == (0, 0):
        return "Blanchard-Kahn condition FAILED: no stable solution."
    return "Blanchard-Kahn status: not reported by this solution object."


def run_ordered_cli(args: argparse.Namespace) -> int:
    """Inspect and execute a source-ordered .mod command program without a QZ prerequisite."""
    import json
    from ._mod_execution import ModCompatibilityError, ModExecutionError
    from .inspection import inspect_mod
    from .model import read_mod

    mod_path = Path(args.model)
    if not mod_path.exists():
        sys.stderr.write(f"Error: Model file '{mod_path}' not found.\n")
        return 1

    data_df: pd.DataFrame | None = None
    data_arg = getattr(args, "data", None) or getattr(args, "shock_decomp", None)
    if data_arg is not None:
        data_path = Path(data_arg)
        if not data_path.exists():
            sys.stderr.write(f"Error: Data file '{data_path}' not found.\n")
            return 1
        try:
            data_df = pd.read_csv(data_path, index_col=0)
        except Exception as exc:
            sys.stderr.write(f"Error reading data file '{data_path}': {exc}\n")
            return 2

    macro_limit = int(getattr(args, "macro_limit", 100000))
    try:
        report = inspect_mod(
            mod_path,
            entry_point="execute_mod_commands",
            ordered=True,
            data=data_df,
            macro_limit=macro_limit,
        )
    except Exception as exc:
        sys.stderr.write(f"Error inspecting model: {exc}\n")
        return 2

    if report.exit_code != 0:
        sys.stderr.write(report.summary() + "\n")
        return int(report.exit_code)

    if not args.quiet:
        sys.stdout.write("=" * 72 + "\n")
        sys.stdout.write(f"  puremacro-dynare: Executing ordered program {mod_path.name}\n")
        sys.stdout.write("=" * 72 + "\n")

    try:
        model = read_mod(mod_path)
    except Exception as exc:
        sys.stderr.write(f"Error compiling model: {exc}\n")
        return 2

    def _serialize_invocations(res_obj) -> list[dict[str, object]]:
        items: list[dict[str, object]] = []
        for inv in getattr(res_obj, "invocations", ()):
            src = getattr(inv, "source", None)
            items.append(
                {
                    "index": int(inv.index),
                    "command": str(inv.command),
                    "status": str(inv.status),
                    "requested_variables": list(inv.requested_variables),
                    "explicit_options": dict(inv.explicit_options),
                    "effective_options": dict(inv.effective_options),
                    "input_fingerprint": str(inv.input_fingerprint),
                    "source": (
                        {
                            "source": str(src.source),
                            "line": int(src.line),
                            "column": None if src.column is None else int(src.column),
                        }
                        if src is not None and hasattr(src, "source")
                        else None
                    ),
                    "error": inv.error,
                }
            )
        return items

    out_dir = Path(getattr(args, "outdir", "./dynare_results"))

    try:
        results = model.execute_mod_commands(data=data_df, ordered=True)
    except ModCompatibilityError as exc:
        sys.stderr.write(str(exc) + "\n")
        return int(exc.report.exit_code or 1)
    except ModExecutionError as exc:
        sys.stderr.write(f"Error executing model commands: {exc}\n")
        try:
            out_dir.mkdir(parents=True, exist_ok=True)
            payload = {
                "model": mod_path.name,
                "status": "failed",
                "source_hashes": dict(model.source_hashes),
                "commands_executed": list(exc.results.commands_executed),
                "invocations": _serialize_invocations(exc.results),
            }
            (out_dir / "command_summary.json").write_text(
                json.dumps(payload, indent=2, sort_keys=True, default=float) + "\n",
                encoding="utf-8",
            )
        except Exception:
            pass
        return 3
    except ValueError as exc:
        sys.stderr.write(f"Error validating execution inputs: {exc}\n")
        return 2
    except Exception as exc:
        sys.stderr.write(f"Error executing model: {exc}\n")
        return 3

    out_dir.mkdir(parents=True, exist_ok=True)

    def write_exports(base_name: str, md_text: str, tex_text: str, typ_text: str) -> None:
        if args.format in ("markdown", "all"):
            (out_dir / f"{base_name}.md").write_text(md_text, encoding="utf-8")
        if args.format in ("latex", "all"):
            (out_dir / f"{base_name}.tex").write_text(tex_text, encoding="utf-8")
        if args.format in ("typst", "all"):
            (out_dir / f"{base_name}.typ").write_text(typ_text, encoding="utf-8")

    payload = {
        "model": mod_path.name,
        "status": "success",
        "source_hashes": dict(model.source_hashes),
        "commands_executed": list(results.commands_executed),
        "invocations": _serialize_invocations(results),
    }
    (out_dir / "command_summary.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True, default=float) + "\n",
        encoding="utf-8",
    )
    write_exports(
        "command_summary",
        results.to_markdown(),
        results.to_latex(),
        results.to_typst(),
    )

    for inv in results.invocations:
        if inv.status != "success" or inv.result is None:
            continue
        if inv.command in ("perfect_foresight_solver", "simul") and hasattr(inv.result, "path"):
            sel_df = (
                inv.selected_result
                if isinstance(inv.selected_result, pd.DataFrame)
                else inv.result.path
            )
            sel_df.to_csv(out_dir / f"invocation_{inv.index}_{inv.command}.csv", index=True)
            inv.result.path.to_csv(out_dir / "perfect_foresight_path.csv", index=True)
            write_exports(
                "perfect_foresight",
                inv.result.to_markdown(),
                inv.result.to_latex(),
                inv.result.to_typst(),
            )
            if getattr(args, "plot", False):
                try:
                    import matplotlib.pyplot as plt

                    fig = inv.result.plot(style="publication")
                    if fig is not None:
                        fig.savefig(out_dir / "perfect_foresight.png", dpi=300, bbox_inches="tight")
                        plt.close(fig)
                except Exception:
                    pass
        elif inv.command == "steady" and isinstance(inv.result, pd.Series):
            inv.result.to_csv(out_dir / f"invocation_{inv.index}_steady.csv", header=True)
            inv.result.to_csv(out_dir / "steady_state.csv", header=True)
        elif inv.command == "stoch_simul":
            sim_res = inv.selected_result if inv.selected_result is not None else inv.result
            write_exports(
                "model_moments",
                sim_res.to_markdown(),
                sim_res.to_latex(),
                sim_res.to_typst(),
            )
            if getattr(sim_res, "irfs", None):
                pd.DataFrame(sim_res.irfs).to_csv(out_dir / "irfs.csv", index=True)
                pd.DataFrame(sim_res.irfs).to_csv(
                    out_dir / f"invocation_{inv.index}_irfs.csv", index=True
                )
        elif inv.command == "calib_smoother":
            sm_res = inv.selected_result if inv.selected_result is not None else inv.result
            if hasattr(sm_res, "states"):
                sm_res.states.to_csv(out_dir / "smoothed_states.csv", index=True)
                sm_res.states.to_csv(
                    out_dir / f"invocation_{inv.index}_calib_smoother.csv", index=True
                )
        elif inv.command == "shock_decomposition":
            sd_res = inv.selected_result if inv.selected_result is not None else inv.result
            write_exports(
                "shock_decomposition",
                sd_res.to_markdown(),
                sd_res.to_latex(),
                sd_res.to_typst(),
            )

    if not args.quiet:
        sys.stdout.write(results.summary() + "\n")
        sys.stdout.write(f"All results saved to: {out_dir.resolve()}\n")
        sys.stdout.write("=" * 72 + "\n")

    return 0


def run_cli(argv: Sequence[str] | None = None) -> int:
    parser = create_parser()
    args = parser.parse_args(argv)

    if getattr(args, "command", None) == "inspect":
        from .inspection import inspect_mod
        try:
            report = inspect_mod(Path(args.model), entry_point=args.entry_point,
                                 ordered=args.ordered, macro_limit=args.macro_limit)
            output = report.to_json() if args.format == "json" else report.summary()
            if args.output:
                Path(args.output).write_text(output + "\n", encoding="utf-8")
            else:
                sys.stdout.write(output + "\n")
            return report.exit_code
        except (ValueError, OSError) as exc:
            sys.stderr.write(f"Error inspecting model: {exc}\n")
            return 2
    if getattr(args, "command", None) == "execute" or getattr(args, "ordered", False):
        return run_ordered_cli(args)
    if getattr(args, "command", None) == "parity":
        return run_parity_cli(args)

    mod_path = Path(args.model)
    if not mod_path.exists():
        sys.stderr.write(f"Error: Model file '{mod_path}' not found.\n")
        return 1

    from puremacro.dsge.dynare import load_mod
    from puremacro.dsge.klein import BlanchardKahnError

    if not args.quiet:
        sys.stdout.write("=" * 72 + "\n")
        sys.stdout.write(f"  puremacro-dynare: Solving {mod_path.name}\n")
        sys.stdout.write("=" * 72 + "\n")

    try:
        model = load_mod(mod_path, order=args.order)
    except BlanchardKahnError as exc:
        sys.stderr.write(f"Error solving model: {exc}\n")
        sys.stderr.write(
            "The Blanchard-Kahn condition fails, so there is no unique stable "
            "rational-expectations solution to report.\n"
        )
        return 3
    except Exception as exc:
        sys.stderr.write(f"Error parsing model: {exc}\n")
        return 2

    # Display steady state
    if not args.quiet:
        vars_list = list(getattr(model, "variables", []))
        shocks_list = list(getattr(model, "shocks", []))
        params_dict = (
            getattr(model, "parameters", None)
            or getattr(model, "params", None)
            or getattr(model, "_params", None)
            or {}
        )
        n_eqs = len(getattr(model, "equations", vars_list))
        sys.stdout.write("Model Summary:\n")
        sys.stdout.write(f"  Equations   : {n_eqs}\n")
        sys.stdout.write(f"  Endogenous  : {len(vars_list)}\n")
        sys.stdout.write(f"  Exogenous   : {len(shocks_list)}\n")
        sys.stdout.write(f"  Parameters  : {len(params_dict)}\n\n")

        sys.stdout.write("Steady State:\n")
        ss = getattr(model, "steady_state", {})
        if hasattr(ss, "items"):
            for var, val in sorted(ss.items(), key=lambda x: str(x[0])):
                sys.stdout.write(f"  {str(var):<20s} = {float(val):14.6f}\n")
        elif isinstance(ss, (list, tuple, np.ndarray)):
            for var, val in zip(vars_list, ss):
                sys.stdout.write(f"  {str(var):<20s} = {float(val):14.6f}\n")
        sys.stdout.write("\n")

    if args.steady_only:
        return 0

    out_dir = Path(args.outdir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Solve dynamic model
    if not args.quiet:
        sys.stdout.write(f"Solving dynamic perturbation at order {args.order}...\n")

    try:
        sim_res = model.stoch_simul(
            order=args.order,
            periods=args.periods,
            irf=args.irf,
        )
    except Exception as exc:
        sys.stderr.write(f"Error solving model: {exc}\n")
        return 3

    if not args.quiet:
        sys.stdout.write(f"{_bk_status_line(model)}\n")
        sys.stdout.write("Decision rules computed successfully.\n\n")

    # Export formats helper
    def write_exports(base_name: str, md_text: str, tex_text: str, typ_text: str):
        if args.format in ("markdown", "all"):
            (out_dir / f"{base_name}.md").write_text(md_text, encoding="utf-8")
        if args.format in ("latex", "all"):
            (out_dir / f"{base_name}.tex").write_text(tex_text, encoding="utf-8")
        if args.format in ("typst", "all"):
            (out_dir / f"{base_name}.typ").write_text(typ_text, encoding="utf-8")

    # 1. Summary tables
    write_exports(
        "model_moments",
        sim_res.to_markdown(),
        sim_res.to_latex(),
        sim_res.to_typst(),
    )

    # 2. IRF plots & data
    if sim_res.irfs:
        irf_df = pd.DataFrame(sim_res.irfs)
        irf_df.to_csv(out_dir / "irfs.csv", index=True)
        if args.plot:
            try:
                import matplotlib.pyplot as plt
                fig = sim_res.plot(style="publication")
                if fig is not None:
                    fig.savefig(out_dir / "irfs.png", dpi=300, bbox_inches="tight")
                    plt.close(fig)
            except Exception as e:
                if not args.quiet:
                    sys.stdout.write(f"Warning saving plot: {e}\n")

    # 3. FEVD if requested
    if args.fevd:
        if not args.quiet:
            sys.stdout.write("Computing Forecast Error Variance Decomposition (FEVD)...\n")
        try:
            from puremacro.dsge.decomposition import compute_fevd
            fevd_res = compute_fevd(model, horizons=[1, 4, 8, 16, 32, None])
            write_exports(
                "fevd",
                fevd_res.to_markdown(),
                fevd_res.to_latex(),
                fevd_res.to_typst(),
            )
            fevd_res.table.to_csv(out_dir / "fevd.csv")
            if args.plot:
                import matplotlib.pyplot as plt
                fig_fevd = fevd_res.plot(style="publication")
                if fig_fevd is not None:
                    fig_fevd.savefig(out_dir / "fevd.png", dpi=300, bbox_inches="tight")
                    plt.close(fig_fevd)
            if not args.quiet:
                sys.stdout.write("FEVD exported successfully.\n")
        except Exception as exc:
            sys.stderr.write(f"Warning: Failed to compute FEVD: {exc}\n")

    # 4. Historical shock decomposition if requested
    if args.shock_decomp:
        decomp_path = Path(args.shock_decomp)
        if not decomp_path.exists():
            sys.stderr.write(f"Warning: Data file for shock decomposition '{decomp_path}' not found.\n")
        else:
            if not args.quiet:
                sys.stdout.write(f"Computing historical shock decomposition from {decomp_path.name}...\n")
            try:
                from puremacro.dsge.decomposition import compute_shock_decomposition
                data_df = pd.read_csv(decomp_path, index_col=0)
                decomp_res = compute_shock_decomposition(model, data_df)
                write_exports(
                    "shock_decomposition",
                    decomp_res.to_markdown(),
                    decomp_res.to_latex(),
                    decomp_res.to_typst(),
                )
                if not args.quiet:
                    sys.stdout.write("Historical shock decomposition exported successfully.\n")
            except Exception as exc:
                sys.stderr.write(f"Warning: Failed shock decomposition: {exc}\n")

    if not args.quiet:
        sys.stdout.write(f"\nAll results saved to: {out_dir.resolve()}\n")
        sys.stdout.write("=" * 72 + "\n")

    return 0


def main(argv: Sequence[str] | None = None) -> None:
    sys.exit(run_cli(argv))


if __name__ == "__main__":
    main()
