"""Canonical Macroeconomic Research Datasets.

Provides built-in, offline loaders for empirical macroeconomic benchmark data:
- Galí (1999, AER): Technology shocks and hours worked.
- Mertens & Ravn (2013, AER): Narrative tax liability shocks.
- US Macroeconomic Quarterly Panel (GDP, Investment, Inflation, Fed Funds).
- US Macroeconomic Monthly Panel (CPI, Core CPI, Unemployment, FFR, NFCI).
- DICE-2016 Climate-Macro Parameters (Nordhaus 2018).
- US state and county geography (Census 2023 Gazetteer internal points) for
  the spatial weights builders in `puremacro.spatial`.
"""
from puremacro.datasets.loaders import (
    load_gali1999,
    load_narrative_tax_shocks,
    load_macro_quarterly,
    load_macro_monthly,
    load_banxico_stance,
    load_dice_parameters,
    load_us_state_centroids,
    load_us_county_centroids,
    list_datasets,
)

from puremacro.datasets.enigh import load_enigh2024_deciles

__all__ = [
    "load_enigh2024_deciles",
    "load_gali1999",
    "load_narrative_tax_shocks",
    "load_macro_quarterly",
    "load_macro_monthly",
    "load_banxico_stance",
    "load_dice_parameters",
    "load_us_state_centroids",
    "load_us_county_centroids",
    "list_datasets",
]
